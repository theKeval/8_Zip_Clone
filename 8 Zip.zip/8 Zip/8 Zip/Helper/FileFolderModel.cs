﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _8_Zip.Helper
{
    public class FileFolderModel
    {
        public string name { get; set; }
        public bool isFolder { get; set; }
    }
}
